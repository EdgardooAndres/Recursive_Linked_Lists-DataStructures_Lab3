package menuClasses;

public class RemoveDocumentAction implements Action {

	@Override
	public void execute(Object args) {
		// TODO Auto-generated method stub

	}

}
